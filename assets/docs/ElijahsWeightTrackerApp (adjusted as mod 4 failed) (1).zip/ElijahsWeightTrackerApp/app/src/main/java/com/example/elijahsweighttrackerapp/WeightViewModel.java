package com.example.elijahsweighttrackerapp;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class WeightViewModel extends AndroidViewModel {

    private final WeightRepository repository;

    public WeightViewModel(@NonNull Application application) {
        super(application);
        repository = new WeightRepository(application);
    }

    public LiveData<List<WeightEntry>> getUserEntries(int userId) {
        return repository.getUserEntries(userId);
    }

    public LiveData<Double> getUserGoalWeight(int userId) {
        return repository.getUserGoalWeight(userId);
    }

    public void insertWeightEntry(WeightEntry entry) {
        repository.insertWeightEntry(entry);
    }

    public void deleteWeightEntryById(long id) {
        repository.deleteWeightEntryById(id);
    }

    public void updateGoalWeight(int userId, double goal) {
        repository.updateGoalWeight(userId, goal);
    }

    public void registerUser(String username, String password, WeightRepository.AuthCallback callback) {
        repository.registerUser(username, password, callback);
    }

    public void validateUser(String username, String password, WeightRepository.AuthCallback callback) {
        repository.validateUser(username, password, callback);
    }

    public List<WeightEntry> getMovingAverages(List<WeightEntry> rawEntries) {
        return WeightAnalyticsUtils.calculateMovingAverage(rawEntries, 7); // 7-day window
    }
}