package com.example.elijahsweighttrackerapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface UserDao {
    @Insert
    long insertUser(UserEntity user);

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserEntity getUserByUsername(String username);

    @Query("SELECT goalWeight FROM users WHERE userId = :userId")
    LiveData<Double> getUserGoalWeight(int userId);

    @Query("UPDATE users SET goalWeight = :goal WHERE userId = :userId")
    void updateGoalWeight(int userId, double goal);
}