package com.example.elijahsweighttrackerapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface UserDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insertUser(UserEntity user);

    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    UserEntity getUserByUsername(String username);

    @Query("SELECT goalWeight FROM users WHERE id = :userId")
    LiveData<Double> getGoalWeightForUser(int userId);

    @Query("UPDATE users SET goalWeight = :goalWeight WHERE id = :userId")
    void updateGoalWeight(int userId, double goalWeight);
}