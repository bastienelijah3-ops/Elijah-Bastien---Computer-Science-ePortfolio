package com.example.elijahsweighttrackerapp;

import android.app.Application;
import androidx.lifecycle.LiveData;

import org.mindrot.jbcrypt.BCrypt;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeightRepository {

    public interface AuthCallback {
        void onSuccess(int userId, String username);
        void onFailure(String errorMessage);
    }

    private final UserDao userDao;
    private final WeightDao weightDao;
    private final ExecutorService executorService;

    public WeightRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        userDao = db.userDao();
        weightDao = db.weightDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<WeightEntry>> getUserEntries(int userId) {
        return weightDao.getAllEntriesForUser(userId);
    }

    public LiveData<List<WeightEntry>> getWeightEntriesForUser(int userId) {
        return weightDao.getWeightEntriesForUser(userId);
    }

    public void insert(WeightEntry entry) {
        executorService.execute(() -> weightDao.insert(entry));
    }

    public void insertWeightEntry(WeightEntry entry) {
        executorService.execute(() -> weightDao.insertWeightEntry(entry));
    }

    public void updateWeightEntry(WeightEntry entry) {
        executorService.execute(() -> weightDao.updateWeightEntry(entry));
    }

    public void delete(long id) {
        executorService.execute(() -> weightDao.deleteById(id));
    }

    public void deleteWeightEntryById(long id) {
        executorService.execute(() -> weightDao.deleteWeightEntryById(id));
    }

    public LiveData<Double> getUserGoalWeight(int userId) {
        return userDao.getUserGoalWeight(userId);
    }

    public void updateGoalWeight(int userId, double goal) {
        executorService.execute(() -> userDao.updateGoalWeight(userId, goal));
    }

    public void registerUser(String username, String password, AuthCallback callback) {
        executorService.execute(() -> {
            UserEntity existing = userDao.getUserByUsername(username);
            if (existing != null) {
                callback.onFailure("Username already exists");
            } else {
                String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
                UserEntity newUser = new UserEntity(username, hashedPassword);
                long id = userDao.insertUser(newUser);
                callback.onSuccess((int) id, username);
            }
        });
    }

    public void validateUser(String username, String password, AuthCallback callback) {
        executorService.execute(() -> {
            UserEntity user = userDao.getUserByUsername(username);
            if (user != null && BCrypt.checkpw(password, user.getPasswordHash())) {
                callback.onSuccess(user.getUserId(), user.getUsername());
            } else {
                callback.onFailure("Invalid username or password");
            }
        });
    }
}