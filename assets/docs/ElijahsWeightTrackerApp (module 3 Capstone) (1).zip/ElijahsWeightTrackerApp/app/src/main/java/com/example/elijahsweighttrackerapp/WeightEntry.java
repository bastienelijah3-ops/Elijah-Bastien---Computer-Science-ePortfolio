package com.example.elijahsweighttrackerapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weight_entries")
public class WeightEntry {
    @PrimaryKey(autoGenerate = true)
    private long id;
    private int userId;
    private double weight;
    private String date;

    public WeightEntry(int userId, double weight, String date) {
        this.userId = userId;
        this.weight = weight;
        this.date = date;
    }

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public double getWeight() { return weight; }
    public void setWeight(double weight) { this.weight = weight; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }
}