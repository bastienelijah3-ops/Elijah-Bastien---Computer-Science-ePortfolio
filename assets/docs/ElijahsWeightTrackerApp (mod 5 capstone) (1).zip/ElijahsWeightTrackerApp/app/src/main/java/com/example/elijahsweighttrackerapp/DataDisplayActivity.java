package com.example.elijahsweighttrackerapp;
// note to self update xml files
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;

public class DataDisplayActivity extends AppCompatActivity implements WeightAdapter.OnItemClickListener {

    private WeightViewModel weightViewModel;
    private int userId;
    private String username;
    private double targetGoal = 0.0;

    private TextView tvWelcomeUser;
    private TextView tvTargetGoalValue;
    private RecyclerView rvWeightData;
    private WeightAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
        userId = prefs.getInt("USER_ID", -1);
        username = prefs.getString("USERNAME", getString(R.string.default_username));

        tvWelcomeUser = findViewById(R.id.tvWelcomeUser);
        tvTargetGoalValue = findViewById(R.id.tvTargetGoalValue);
        rvWeightData = findViewById(R.id.rvWeightData);
        FloatingActionButton btnAddWeight = findViewById(R.id.btnAddWeight);
        Button btnUpdateGoal = findViewById(R.id.btnUpdateGoal);

        tvWelcomeUser.setText(getString(R.string.welcome_user, username));

        rvWeightData.setLayoutManager(new GridLayoutManager(this, 1));
        adapter = new WeightAdapter(this);
        rvWeightData.setAdapter(adapter);

        weightViewModel = new ViewModelProvider(this).get(WeightViewModel.class);

        weightViewModel.getUserEntries(userId).observe(this, entries -> {
            if (entries != null) {
                adapter.setEntries(entries);
            }
        });

        weightViewModel.getUserGoalWeight(userId).observe(this, goal -> {
            if (goal != null) {
                targetGoal = goal;
                tvTargetGoalValue.setText(String.format("%.1f lbs", targetGoal));
            }
        });

        btnAddWeight.setOnClickListener(v -> showAddDialog());
        btnUpdateGoal.setOnClickListener(v -> showGoalDialog());
    }

    @Override
    public void onItemClick(WeightEntry entry) {
        // Option to edit entry on item click
    }

    @Override
    public void onDeleteClick(WeightEntry entry) {
        if (entry != null) {
            weightViewModel.deleteWeightEntryById(entry.getId());
            Toast.makeText(this, R.string.msg_record_deleted, Toast.LENGTH_SHORT).show();
        }
    }

    private void showAddDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight, null);
        builder.setView(dialogView);

        TextInputEditText etWeight = dialogView.findViewById(R.id.etDialogWeight);
        TextInputEditText etDate = dialogView.findViewById(R.id.etDialogDate);
        Button btnSave = dialogView.findViewById(R.id.btnSaveWeight);
        Button btnCancel = dialogView.findViewById(R.id.btnCancelWeight);

        AlertDialog dialog = builder.create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSave.setOnClickListener(v -> {
            String weightStr = etWeight.getText() != null ? etWeight.getText().toString().trim() : "";
            String dateStr = etDate.getText() != null ? etDate.getText().toString().trim() : "";

            if (!weightStr.isEmpty() && !dateStr.isEmpty()) {
                try {
                    double weight = Double.parseDouble(weightStr);
                    WeightEntry entry = new WeightEntry(userId, weight, dateStr);
                    weightViewModel.insertWeightEntry(entry);
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, R.string.error_invalid_weight, Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, R.string.error_invalid_input, Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    private void showGoalDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_weight, null);
        builder.setView(dialogView);

        TextInputEditText etGoal = dialogView.findViewById(R.id.etDialogWeight);
        Button btnSave = dialogView.findViewById(R.id.btnSaveWeight);
        Button btnCancel = dialogView.findViewById(R.id.btnCancelWeight);

        AlertDialog dialog = builder.create();

        btnCancel.setOnClickListener(v -> dialog.dismiss());
        btnSave.setOnClickListener(v -> {
            String goalStr = etGoal.getText() != null ? etGoal.getText().toString().trim() : "";
            if (!goalStr.isEmpty()) {
                try {
                    double goal = Double.parseDouble(goalStr);
                    weightViewModel.updateGoalWeight(userId, goal);
                    dialog.dismiss();
                } catch (NumberFormatException e) {
                    Toast.makeText(this, R.string.error_invalid_weight, Toast.LENGTH_SHORT).show();
                }
            }
        });

        dialog.show();
    }
}