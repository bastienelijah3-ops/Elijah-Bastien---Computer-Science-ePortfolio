package com.example.elijahsweighttrackerapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

public class LoginActivity extends AppCompatActivity implements WeightRepository.AuthCallback {

    private WeightViewModel weightViewModel;
    private EditText etUsername;
    private EditText etPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnRegister = findViewById(R.id.btnRegister);

        weightViewModel = new ViewModelProvider(this).get(WeightViewModel.class);

        btnLogin.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                weightViewModel.validateUser(username, password, LoginActivity.this);
            } else {
                Toast.makeText(this, R.string.error_invalid_input, Toast.LENGTH_SHORT).show();
            }
        });

        btnRegister.setOnClickListener(v -> {
            String username = etUsername.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (!username.isEmpty() && !password.isEmpty()) {
                weightViewModel.registerUser(username, password, LoginActivity.this);
            } else {
                Toast.makeText(this, R.string.error_invalid_input, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onSuccess(int userId) {
        runOnUiThread(() -> {
            String username = etUsername.getText().toString().trim();

            SharedPreferences prefs = getSharedPreferences("UserSession", MODE_PRIVATE);
            prefs.edit()
                    .putInt("USER_ID", userId)
                    .putString("USERNAME", username)
                    .apply();

            Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
            startActivity(intent);
            finish();
        });
    }

    @Override
    public void onFailure(String errorMessage) {
        runOnUiThread(() -> Toast.makeText(LoginActivity.this, errorMessage, Toast.LENGTH_SHORT).show());
    }
}