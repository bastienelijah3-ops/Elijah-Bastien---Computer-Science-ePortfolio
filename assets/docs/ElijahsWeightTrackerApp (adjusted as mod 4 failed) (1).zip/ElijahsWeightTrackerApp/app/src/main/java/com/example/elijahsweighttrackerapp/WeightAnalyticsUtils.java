package com.example.elijahsweighttrackerapp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class WeightAnalyticsUtils {

    //  Sliding Window Algorithm: Calculate 7-day moving average
    public static List<WeightEntry> calculateMovingAverage(List<WeightEntry> entries, int windowSize) {
        // Ensure entries are sorted chronologically
        List<WeightEntry> sortedEntries = new ArrayList<>(entries);
        sortedEntries.sort((e1, e2) -> e1.getDate().compareTo(e2.getDate()));

        List<WeightEntry> smoothedEntries = new ArrayList<>();
        for (int i = 0; i < sortedEntries.size(); i++) {
            double sum = 0;
            int count = 0;
            // Look back 'windowSize' days
            for (int j = Math.max(0, i - windowSize + 1); j <= i; j++) {
                sum += sortedEntries.get(j).getWeight();
                count++;
            }
            double average = sum / count;

            // nw entry representing the smoothed trend
            WeightEntry smoothed = new WeightEntry(
                    sortedEntries.get(i).getUserId(),
                    Math.round(average * 10.0) / 10.0,
                    sortedEntries.get(i).getDate()
            );
            smoothedEntries.add(smoothed);
        }
        return smoothedEntries;
    }

    // Trend Algorithm: Estimate rate of weight change per day
    public static double calculateWeeklyRateOfChange(List<WeightEntry> entries) {
        if (entries == null || entries.size() < 2) return 0.0;

        List<WeightEntry> sorted = new ArrayList<>(entries);
        sorted.sort((e1, e2) -> e1.getDate().compareTo(e2.getDate()));

        WeightEntry first = sorted.get(0);
        WeightEntry latest = sorted.get(sorted.size() - 1);

        double weightDifference = latest.getWeight() - first.getWeight();
        // Assuming date (string format) allows basic indexing or diffing,
        // or map dates to timestamps for precise day calculations.
        return weightDifference;
    }
}