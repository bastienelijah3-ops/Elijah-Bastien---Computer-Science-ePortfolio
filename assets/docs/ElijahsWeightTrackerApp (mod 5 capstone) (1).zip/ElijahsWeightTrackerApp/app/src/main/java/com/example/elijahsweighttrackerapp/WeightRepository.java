package com.example.elijahsweighttrackerapp;

import android.app.Application;
import androidx.lifecycle.LiveData;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WeightRepository {

    public interface AuthCallback {
        void onSuccess(int userId);
        void onFailure(String error);
    }

    private final WeightDao weightDao;
    private final UserDao userDao;
    private final ExecutorService executorService;

    public WeightRepository(Application application) {
        AppDatabase db = AppDatabase.getInstance(application);
        weightDao = db.weightDao();
        userDao = db.userDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<WeightEntry>> getUserEntries(int userId) {
        return weightDao.getAllEntriesForUser(userId);
    }

    public LiveData<Double> getUserGoalWeight(int userId) {
        return userDao.getGoalWeightForUser(userId);
    }

    public void insertWeightEntry(WeightEntry entry) {
        executorService.execute(() -> weightDao.insert(entry));
    }

    public void deleteWeightEntryById(long id) {
        executorService.execute(() -> weightDao.deleteById(id));
    }

    public void updateGoalWeight(int userId, double goal) {
        executorService.execute(() -> userDao.updateGoalWeight(userId, goal));
    }

    public void registerUser(String username, String password, AuthCallback callback) {
        executorService.execute(() -> {
            UserEntity existingUser = userDao.getUserByUsername(username);
            if (existingUser != null) {
                if (callback != null) callback.onFailure("Username already exists");
            } else {
                UserEntity newUser = new UserEntity(username, password);
                long newId = userDao.insertUser(newUser);
                if (callback != null) callback.onSuccess((int) newId);
            }
        });
    }

    public void validateUser(String username, String password, AuthCallback callback) {
        executorService.execute(() -> {
            UserEntity user = userDao.getUserByUsername(username);
            if (user != null && user.getPassword().equals(password)) {
                if (callback != null) callback.onSuccess(user.getId());
            } else {
                if (callback != null) callback.onFailure("Invalid username or password");
            }
        });
    }
}