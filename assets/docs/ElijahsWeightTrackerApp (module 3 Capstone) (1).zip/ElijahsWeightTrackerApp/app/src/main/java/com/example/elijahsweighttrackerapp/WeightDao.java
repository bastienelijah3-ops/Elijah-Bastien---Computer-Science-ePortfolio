package com.example.elijahsweighttrackerapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface WeightDao {
    @Insert
    long insert(WeightEntry entry);

    @Insert
    long insertWeightEntry(WeightEntry entry);

    @Update
    void updateWeightEntry(WeightEntry entry);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY id DESC")
    LiveData<List<WeightEntry>> getAllEntriesForUser(int userId);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY id DESC")
    LiveData<List<WeightEntry>> getWeightEntriesForUser(int userId);

    @Query("DELETE FROM weight_entries WHERE id = :id")
    void deleteById(long id);

    @Query("DELETE FROM weight_entries WHERE id = :id")
    void deleteWeightEntryById(long id);
}