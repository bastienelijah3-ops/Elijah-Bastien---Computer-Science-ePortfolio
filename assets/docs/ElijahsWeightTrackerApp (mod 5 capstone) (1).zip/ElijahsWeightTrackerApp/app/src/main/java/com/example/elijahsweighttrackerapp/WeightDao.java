package com.example.elijahsweighttrackerapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WeightDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(WeightEntry entry);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY date DESC")
    LiveData<List<WeightEntry>> getAllEntriesForUser(int userId);

    @Query("SELECT * FROM weight_entries WHERE userId = :userId ORDER BY date DESC")
    LiveData<List<WeightEntry>> getWeightEntriesForUser(int userId);

    @Query("DELETE FROM weight_entries WHERE id = :id")
    void deleteById(long id);
}